# ds200

The data set used is the Indian Petroleum and Natural Gas Statistics - 2017-18 from https://data.gov.in/

(a)Scatter Plot:

 The scatter plot attached shows how the Export Quantity of various Petroleum Products is varying over the years.
		It can be observed from the plot that except petrol , the export quantity of all the other petroleum products increased from that in 2011 to  2018.

(b)Box plot:

The Box plot attached shows the individual distribution of the different petroleum products over the years.
		It can be observed that for LPG,Kerosene,Lubes,Bitumen the values remain almost the same over the years.Huge variation of Quantity exported happened in the case of Petrol,Diesel and in the case of Fuel oil.

(c)Line Plot:

The Line plot attached shows the variation of the Import Quantity of Petrol over the years.
		It can be observed that the Import Quantity of petrol was highest in the year 2015-16 and from there it dropped in the subsequent years to second lowest value in seven years.

Reference :https://data.gov.in/resources/importexport-crude-oil-and-petroleum-products-rs-value-terms-2011-12-2017-18

please Note that the csv file which I downloaded from this above link had an error in line 17 of this csv , so I had manually edited it and I am putting the edited dataset in the github page.You can view the python file used to Generate the plots and the dataset used in the module4.zip file.

For executing the code in Terminal type : python plotgraph.py
